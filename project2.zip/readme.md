### SPIMI implementation

##### ***How it works***:
    run the query_process.py file and follow the instructions

##### ***Notes***:
    Index folder contains the combined Inverted Index file used for query processing
    
